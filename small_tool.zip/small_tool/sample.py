import numpy as np

# y = np.array([[2,4,5],[5,6,7]])
# for i in y:
#     print(i)
# print(len(y))

def sample1(x):
    a = 1
    b = 2
    return a,b

def sample2(x):
    a = 1
    b = 2
    return a,b

for ()